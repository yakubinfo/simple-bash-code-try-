#!/bin/bash
FILES=( $1 $2 $3 )
for ELEMENT in ${FILES[@]}
do
        echo "${ELEMENT}"
done

echo "Echo\'d all the files"

