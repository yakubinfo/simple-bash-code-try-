#!/bin/bash

MY_NAME=$1
NAME_1=$2
NAME_2=$3
NAME_3=$4
Name_4=$5

if [ "${MY_NAME}" == "Ron" ]; then
    echo "Ron is home from vacation"
elif [[ "${MY_NAME}" != ${NAME_1}" && "${MY_NAME}" != ${NAME_2}" && "${MY_NAME}" == "John" ]]; then
    echo "John is home after some unnecessary AND logic"
elif [ "${MY_NAME}" == ${NAME_3}" || "${MY_NAME}" == ${NAME_4}" ]; then
    echo "Looks like one of the ladies are home"
else
    echo "Who is this stranger?"
fi

