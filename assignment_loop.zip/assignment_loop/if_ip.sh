#!/bin/bash

AGE=$1
if [ ${AGE} -lt 18 ]; then
    echo "You must be 18 or older to see this movie"
fi
