#!/bin/bash
echo "enter the files name:"
read FILES
for ELEMENT in ${FILES[@]}
do
        echo "${ELEMENT}"
done

echo "Echo\'d all the files"

