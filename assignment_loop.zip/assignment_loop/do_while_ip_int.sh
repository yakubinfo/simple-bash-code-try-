#!/bin/bash

echo "please enter the desired input: $CTR"
read CTR
while [ ${CTR} -lt 9 ]
do
    echo "CTR var: ${CTR}"
    ((CTR++))
done
echo "Finished"
