#!/bin/bash
echo "enter your name :) :"
read MY_NAME
echo "enter your name :) :"
read NAME_1
echo "enter your name :) :"
read NAME_2
echo "enter your name :) :"
read NAME_3
echo "enter your name :) :"
read Name_4

if [ "${MY_NAME}" == "Ron" ]; then
    echo "Ron is home from vacation"
elif [[ "${MY_NAME}" != ${NAME_1}" && "${MY_NAME}" != ${NAME_2}" && "${MY_NAME}" == "John" ]]; then
    echo "John is home after some unnecessary AND logic"
elif [ "${MY_NAME}" == ${NAME_3}" || "${MY_NAME}" == ${NAME_4}" ]; then
    echo "Looks like one of the ladies are home"
else
    echo "Who is this stranger?"
fi

